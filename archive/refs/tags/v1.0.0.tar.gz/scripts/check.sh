#!/bin/bash

# GitHub username (replace with your username)
USERNAME="hellobdo"

# The file to check against
WIKI_FILE="/Users/brunodeoliveira/Library/Mobile Documents/com~apple~CloudDocs/repos/obsidian-vaults/bdo/projects/! githubwiki/wiki.md"

# File to store repos not found
NOT_FOUND_FILE="repos_not_found.txt"

# Initialize counters
TOTAL_REPOS=0
FOUND_REPOS=0
NOT_FOUND_REPOS=0

# Function to get repos for an organization
get_org_repos() {
  local org_name=$1
  gh repo list "$org_name" --limit 1000 --json name --jq '.[].name' | while read -r repo; do
    echo "$org_name/$repo"
  done
}

# Get the list of personal repos from GitHub (only names, no extra data)
PERSONAL_REPOS=$(gh repo list "$USERNAME" --limit 1000 --json name --jq '.[].name' | while read -r repo; do
  echo "$USERNAME/$repo"
done)

# Get the list of organizations the user is part of
ORG_LIST=$(gh api "/user/orgs" --jq '.[].login')

# Combine personal repos and org repos
ALL_REPOS="$PERSONAL_REPOS"

# Iterate through each organization and get their repos
for ORG in $ORG_LIST; do
  echo "Fetching repos for organization: $ORG"
  ORG_REPOS=$(get_org_repos "$ORG")
  ALL_REPOS="$ALL_REPOS $ORG_REPOS"
done

# Iterate over each repo name (personal and org repos)
for REPO in $ALL_REPOS; do
  TOTAL_REPOS=$((TOTAL_REPOS + 1))

  # Check if the repo name exists in the githubWiki.md file
  if ! grep -q "$REPO" "$WIKI_FILE"; then
    # If repo name is not found in the file, update the not found counter
    NOT_FOUND_REPOS=$((NOT_FOUND_REPOS + 1))
    # Only create the not found file if necessary
    if [ "$NOT_FOUND_REPOS" -eq 1 ]; then
      > "$NOT_FOUND_FILE"  # Clear or create the file if it's the first not found repo
    fi
    echo "Repository '$REPO' not found in $WIKI_FILE" >> "$NOT_FOUND_FILE"
  else
    # If repo name is found, update the found counter
    FOUND_REPOS=$((FOUND_REPOS + 1))
  fi
done

# Output total summary to the terminal
echo "Total Repos: $TOTAL_REPOS"
echo "Repos found in $WIKI_FILE: $FOUND_REPOS"
echo "Repos not found in $WIKI_FILE: $NOT_FOUND_REPOS"

# If all repos are found, add the "all good mate" message and skip creating the file
if [ "$NOT_FOUND_REPOS" -eq 0 ]; then
  echo "It's all good mate ✅"
fi