#!/bin/bash

git add .
git commit
git push
